import { useEffect, useState } from 'react';
import { apiClient } from '../../api/client';
import { useLanguage } from '../../context/LanguageContext';
import { Globe, Radio, ChevronRight, ChevronDown, Trophy } from 'lucide-react';
import { isMainFootballCompetition } from '../../utils/sportsbookFilters';

interface Props {
  selectedTournamentId?: string;
  selectedSportId?: string;
  isLiveOnly?: boolean;
  onSelectTournament: (id: string) => void;
  onSelectSport: (id: string) => void;
  onSelectCategory: (id: string) => void;
  onSelectAll: () => void;
  onSelectLive: () => void;
}

const sportIcons: Record<string, string> = {
  Football: '⚽',
  Basketball: '🏀',
  Tennis: '🎾',
  'Ice Hockey': '🏒',
  Volleyball: '🏐'
};

export default function SportsSidebar({
  selectedTournamentId,
  selectedSportId,
  isLiveOnly,
  onSelectTournament,
  onSelectSport,
  onSelectCategory,
  onSelectAll,
  onSelectLive
}: Props) {
  const { t } = useLanguage();
  const [sports, setSports] = useState<any[]>([]);
  const [expandedSports, setExpandedSports] = useState<Record<string, boolean>>({ '1': true }); // Expand Football by default
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({ '1': true }); // Expand England by default

  useEffect(() => {
    apiClient.get('/sports')
      .then(res => setSports(res.data))
      .catch(() => {
        apiClient.get('/sports/tree').then(res => setSports(res.data)).catch(console.error);
      });
  }, []);

  const toggleSport = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedSports(p => ({ ...p, [id]: !p[id] }));
  };

  const toggleCat = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setExpandedCategories(p => ({ ...p, [id]: !p[id] }));
  };

  const isAllActive = !selectedTournamentId && !selectedSportId && !isLiveOnly;

  return (
    <div className="w-64 sm:w-72 bg-secondary border-r border-tertiary h-full flex flex-col select-none text-text-primary">
      {/* Top Quick Filters */}
      <div className="p-3 border-b border-tertiary space-y-2 bg-secondary/80">
        <button
          onClick={onSelectAll}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
            isAllActive
              ? 'bg-gradient-to-r from-emerald-600 to-accent-green text-primary shadow-glow-green'
              : 'bg-primary/60 text-text-secondary hover:text-white hover:bg-tertiary/70 border border-tertiary/60'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Globe size={16} className={isAllActive ? 'text-primary' : 'text-accent-green'} />
            <span className="tracking-wide">{t('sports.all')}</span>
          </div>
          <span className={`text-[10px] px-1.5 py-0.5 rounded font-black ${
            isAllActive ? 'bg-primary/20 text-primary' : 'bg-tertiary text-text-secondary'
          }`}>
            ALL
          </span>
        </button>

        <button
          onClick={onSelectLive}
          className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
            isLiveOnly
              ? 'bg-gradient-to-r from-rose-600 to-accent-red text-white shadow-glow-red'
              : 'bg-primary/60 text-text-secondary hover:text-rose-400 hover:bg-rose-500/10 border border-tertiary/60'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-red opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-accent-red"></span>
            </span>
            <Radio size={16} className={isLiveOnly ? 'text-white' : 'text-rose-400'} />
            <span className="tracking-wide">{t('sports.live')}</span>
          </div>
          <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider ${
            isLiveOnly ? 'bg-white/20 text-white' : 'bg-rose-500/20 text-rose-400'
          }`}>
            LIVE
          </span>
        </button>
      </div>

      {/* Sports Tree */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5 text-xs">
        <div className="px-2.5 py-1 text-[11px] font-black text-text-secondary/70 uppercase tracking-widest flex items-center gap-1.5">
          <Trophy size={13} className="text-accent-yellow/80" />
          <span>{t('nav.sports')}</span>
        </div>

        {sports.map(s => {
          const isSportSelected = selectedSportId === String(s.id);
          const isExpanded = !!expandedSports[s.id];
          const icon = sportIcons[s.name] || '🏆';
          const translatedName = t(`sports.${s.name}`) || s.name;

          return (
            <div key={s.id} className="rounded-xl overflow-hidden transition-colors">
              <div 
                className={`flex items-center justify-between px-3 py-2.5 rounded-xl cursor-pointer transition-all ${
                  isSportSelected
                    ? 'bg-primary border border-accent-green/50 text-white font-bold shadow-sm'
                    : 'hover:bg-primary/60 text-text-primary'
                }`}
                onClick={() => onSelectSport(String(s.id))}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <span className="text-base select-none leading-none">{icon}</span>
                  <span className="font-semibold truncate tracking-tight">{translatedName}</span>
                </div>
                <div 
                  className="p-1 hover:bg-tertiary rounded-lg text-text-secondary hover:text-white transition"
                  onClick={(e) => toggleSport(String(s.id), e)}
                >
                  <ChevronDown
                    size={14}
                    className={`transition-transform duration-200 ${isExpanded ? 'rotate-0' : '-rotate-90'}`}
                  />
                </div>
              </div>

              {/* Categories & Tournaments */}
              {isExpanded && s.categories && (
                <div className="ml-3.5 pl-2.5 border-l border-tertiary/60 my-1 space-y-1">
                  {s.categories.filter((category: any) =>
                    (category.tournaments ?? []).some((tournament: any) =>
                      isMainFootballCompetition(tournament.name, category.name),
                    ),
                  ).map((c: any) => {
                    const isCatExpanded = !!expandedCategories[c.id];
                    return (
                      <div key={c.id}>
                        <div 
                          className="flex items-center justify-between px-2.5 py-1.5 rounded-lg hover:bg-primary/50 cursor-pointer text-text-secondary hover:text-white transition"
                          onClick={(e) => {
                            toggleCat(String(c.id), e);
                            onSelectCategory(String(c.id));
                          }}
                        >
                          <span className="truncate font-medium text-[11px]">{c.name}</span>
                          <ChevronDown
                            size={12}
                            className={`transition-transform duration-150 ${isCatExpanded ? 'rotate-0' : '-rotate-90'}`}
                          />
                        </div>

                        {isCatExpanded && c.tournaments && (
                          <div className="ml-2 pl-2 border-l border-tertiary/40 space-y-0.5 my-0.5">
                            {c.tournaments.filter((tour: any) =>
                              isMainFootballCompetition(tour.name, c.name),
                            ).map((tour: any) => {
                              const isTourSelected = selectedTournamentId === String(tour.id);
                              return (
                                <button
                                  key={tour.id}
                                  onClick={() => onSelectTournament(String(tour.id))}
                                  className={`w-full text-left px-2 py-1.5 rounded-lg text-[11px] truncate transition-all ${
                                    isTourSelected 
                                      ? 'bg-accent-green/20 text-accent-green font-bold border-l-2 border-accent-green pl-2.5' 
                                      : 'text-text-secondary hover:text-white hover:bg-tertiary/40'
                                  }`}
                                >
                                  {tour.name}
                                </button>
                              );
                            })}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
